from phase_stitcher.phase_stitcher import main

if __name__ == "__main__":
    main()
