from setuptools import setup, find_packages

setup(
    install_requires=["numpy>=1.22", "matplotlib>=3", "pandas>=1", "dask>=2021"],
     packages = find_packages(), # list of all packages


)